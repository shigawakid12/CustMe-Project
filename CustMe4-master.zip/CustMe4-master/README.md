# LARAVEL 11 React CRUD

## How to run

```sh
php artisan serve
```
then
```sh
npm run dev
```

### Check the tutorial video
[]
