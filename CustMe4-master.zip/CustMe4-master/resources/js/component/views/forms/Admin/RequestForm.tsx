import React, { useState } from 'react';
import { Box, Typography, Button, Paper, Divider, Modal, CircularProgress } from '@mui/material';
import { useNotification } from '../../../context/NotificationContext';
import { useAuth } from '../../../context/AuthContext';
import { usePayment } from '../../../context/PaymentContext';
import { useLocation } from 'react-router-dom';
import Header from '../components/header';

const RequestForm: React.FC = () => {
    const { notifications, acceptNotification, declineNotification, selectedNotification, setSelectedNotification } = useNotification();
    const { initiatePayment, loading } = usePayment();
    const { user } = useAuth();
    const [isModalOpen, setModalOpen] = useState(false);

    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const successMessage = queryParams.get('success_message');
    const errorMessage = queryParams.get('error_message');

    const handleNotificationClick = (notification: any) => {
        setSelectedNotification(notification);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setSelectedNotification(null);
        setModalOpen(false);
    };

    const handlePayment = async (requestId: number, amount: number, userRole: number, targetUserRole: number, userId: number, targetUserId: number) => {
        let payerId;

        if (userRole === 2 || targetUserRole === 2) {
            payerId = userRole === 2 ? userId : targetUserId;
        } else {
            payerId = userId;
        }

        const checkoutUrl = await initiatePayment(requestId, amount, payerId);
        if (checkoutUrl) {
            window.location.href = checkoutUrl;
        } else {
            console.error('Failed to initiate payment');
        }
    };

    return (
        <Box className="p-4 mt-14">
            <Header />
            {successMessage && (
                <Typography variant="body1" className="text-green-600">
                    {successMessage}
                </Typography>
            )}
            {errorMessage && (
                <Typography variant="body1" className="text-red-600">
                    {errorMessage}
                </Typography>
            )}
            {notifications.length > 0 ? (
                notifications.map((notification) => {
                    const { id, status, request_id, content, created_at, target_user_id, price, user_role, target_user_role } = notification;

                    const bgColor =
                        status === 'accepted' ? 'rgba(16, 185, 129, 0.1)' :
                        status === 'declined' ? 'rgba(239, 68, 68, 0.1)' :
                        'white';

                    return (
                        <Paper
                            key={id}
                            className={`mb-2 p-4 transition-shadow duration-300 flex items-center justify-between`}
                            onClick={() => handleNotificationClick(notification)}
                            style={{ backgroundColor: bgColor }}
                        >
                            <div>
                                <Typography variant="body1" className="text-gray-800">
                                    {content}
                                </Typography>
                                <Typography variant="caption" className="text-gray-600">
                                    {new Date(created_at).toLocaleString()}
                                </Typography>
                                <Divider sx={{ my: 1 }} />
                                {status === 'pending' && (
                                    <Box display="flex" gap={1}>
                                        <Button
                                            variant="contained"
                                            color="primary"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                acceptNotification(id, request_id);
                                            }}
                                            className="bg-blue-500 hover:bg-blue-600"
                                        >
                                            Accept
                                        </Button>
                                        <Button
                                            variant="outlined"
                                            color="secondary"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                declineNotification(id, request_id);
                                            }}
                                            className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white"
                                        >
                                            Decline
                                        </Button>
                                    </Box>
                                )}
                                {status === 'accepted' && user && target_user_id === user.id && (
                                    <Typography variant="body2" className="text-green-600 mt-2">
                                        You accepted this request.
                                    </Typography>
                                )}
                                {status === 'declined' && user && target_user_id === user.id && (
                                    <Typography variant="body2" className="text-red-600 mt-2">
                                        You declined this request.
                                    </Typography>
                                )}
                            </div>

                            {status === 'accepted' && (
                                <div>
                                    <Button
                                        variant="contained"
                                        color="primary"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            handlePayment(request_id, Number(price), user_role, target_user_role, notification.user_id, target_user_id);
                                        }}
                                        className="mt-2"
                                        disabled={loading}
                                    >
                                        {loading ? <CircularProgress size={24} /> : 'Pay Now'}
                                    </Button>
                                </div>
                            )}
                        </Paper>
                    );
                })
            ) : (
                <Typography variant="body2" className="text-gray-800">
                    No notification requests.
                </Typography>
            )}

            <Modal open={isModalOpen} onClose={handleCloseModal}>
                <Box
                    sx={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        width: 400,
                        bgcolor: 'background.paper',
                        boxShadow: 24,
                        p: 4,
                        borderRadius: 2,
                    }}
                >
                    {selectedNotification ? (
                        <>
                            <Typography variant="h6" gutterBottom>
                                Notification Details
                            </Typography>
                            <Typography variant="body1">
                                <strong>Content:</strong> {selectedNotification.content}
                            </Typography>
                            <Typography variant="body1">
                                <strong>Created At:</strong> {new Date(selectedNotification.created_at).toLocaleString()}
                            </Typography>
                            <Typography variant="body1">
                                <strong>Price:</strong> {selectedNotification.price}
                            </Typography>
                            <Typography variant="body1">
                                <strong>Request Content:</strong> {selectedNotification.request_content}
                            </Typography>
                            <Box mt={2}>
                                <Button variant="contained" onClick={handleCloseModal} fullWidth>
                                    Close
                                </Button>
                            </Box>
                        </>
                    ) : (
                        <Typography variant="body1">No data available.</Typography>
                    )}
                </Box>
            </Modal>
        </Box>
    );
};

export default RequestForm;