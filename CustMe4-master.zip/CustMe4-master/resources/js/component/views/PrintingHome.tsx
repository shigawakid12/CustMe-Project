import React from "react";
import PrintingShopHome from "./forms/Printing Shop/PrintingShopHomeForm";


const PrintingHome = () => {
  return (
    <div className=" bg-white">
    <PrintingShopHome />
  </div>
  );
};

export default PrintingHome;
