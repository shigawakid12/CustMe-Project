import React from "react";

import UserHomeForm from "./forms/User/UserHomeForm";


const UserHome = () => {
  return (
    <div className=" bg-white">
    <UserHomeForm/>
  </div>
  );
};

export default UserHome;
