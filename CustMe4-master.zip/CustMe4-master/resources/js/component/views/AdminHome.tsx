import React from "react";
import AdminHomeForm from "./forms/Admin/AdminHomeForm";


const AdminHome = () => {
  return (
    <div className=" bg-white">
    <AdminHomeForm />
  </div>
  );
};

export default AdminHome;
