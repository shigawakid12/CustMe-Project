import React from "react";
import GraphicDesignerHomeForm from "./forms/Graphic Designer/GraphicDesignerHomeForm";


const GraphicHome= () => {
  return (
    <div className=" bg-white">
    <GraphicDesignerHomeForm />
  </div>
  );
};

export default GraphicHome;
